# Make the Case Sheets kit

Existing Sheet: read apps-script/UPDATE-AND-TEST.md first. New copy: read apps-script/README.md.

This kit contains the integrated Coach.html and backend. Live Google-account/provider checks are pending. No API key or private company records are included.
